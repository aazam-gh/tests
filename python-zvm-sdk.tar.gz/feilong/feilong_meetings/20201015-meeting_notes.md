# 2020/10/15 Feilong project meeting

Start Time : Oct 15, 2020 05:26 AM

Meeting Recording:
https://zoom.us/rec/share/4DbaO_ZLCzae9OD5QA-i0ItQikTpoT0GFUbEmoIpGYvaAaoEDDxUr7ZXROsRmTeV.bolPJLwvjJvUN-ds

Access Passcode: 7^.iv!Uw

## Attendees
- Vinnie Terrone
- Dong Ma
- Michel Beaulieu
- James Vincent

## Agenda topics
- Discuss after-the-summer promotion of the Feilong project
- Status on CI/CD and developer infrastructure projects

## Meeting Notes

### Accessing the Feilong github project
- https://github.com/openmainframeproject/feilong

### Discuss after-the-summer promotion of the Feilong project
- Can we work with IBM people to promote that IBM Cloud Infrastructure Center uses Feilong for automation?
- Raise a discussion topic to IBM VM Marist mailing list or Linux on VM mailing list
- Create short video to help promote Feilong running in the developer environment in the second level z/VM

### Status on CI/CD and developer infrastructure projects
- https://github.com/openmainframeproject/feilong/issues/367
  - Dong Ma will summarize current test and proposal
- Mike has made progress on the developer environment and will give an update during the next meeting

## Next meeting agenda topics
- Update on CI/CD and developer infrastructure projects
