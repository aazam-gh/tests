# 2020/05/28 Feilong project meeting

## Attendees
- Len Santalucia
- James Vincent
- Vinnie Terrone
- Mike Friesenegger
- Dong JV Ma

## Agenda topics
- Update on Feilong s390x infrastructure testing
- Mike Friesenegger will present a simple demonstration of python-zvm-sdk in action

## Meeting Notes

##### Meeting recording with audio transcript
https://zoom.us/rec/share/_s5nALP620RJfInLzR_YUK8-AYDAT6a8hiBM-fZbzkrA8OMS7esaoXzVJZ0FQyVE
(Access Password: 8s&k^+09)

### Update on Feilong s390x infrastructure testing
- Dong Ma is able to access CI/CD VMs from Vinnie's instructions
- Len will schedule a webex with the CI/CD team to discuss technical topics

### A simple demonstration of python-zvm-sdk in action
- Watch the recording at timemark 24:52 to see the demo

## Next meeting agenda topics
- Status of CI/CD and developer testing of Vicom Infinity s390x infrastructure
