All participants agree to abide by the Code of Conduct available at https://github.com/openmainframeproject/tsc/blob/master/CODE_OF_CONDUCT.md.
